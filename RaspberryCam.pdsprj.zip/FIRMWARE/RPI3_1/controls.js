// C:/Program Files (x86)/Labcenter Electronics/Proteus 8 Professional/DATA/VSM Studio/controls/Photo/control.js

function Photo (root, config) {
   var obj = this;
   var border = root.getElementsByTagName('rect')[0];
   var bounds = root.getElementsByTagName('rect')[1];
   var imageRegion = root.getElementsByTagName('g')[0];
   var noImageText = imageRegion.getElementsByTagName('text')[0];   
   
            
   var imageArea = imageRegion.getElementsByTagName('rect')[0];  
   var image = null;
   var video = null;
   var source = null;
      
   noImageText.style.pointerEvents='none';
   
   this.reconfigure = function (newInstance) {
      if (newInstance) {        
      }
            
   };
   
   this.update = function () {
      var ctm = root.getCTM();
      var tbt = panel.createSVGTransform();
      tbt.setScale(1/ctm.a, 1/ctm.d);
      border.transform.baseVal.initialize(tbt);
      border.width.baseVal.value = bounds.width.baseVal.value*ctm.a;
      border.height.baseVal.value = bounds.height.baseVal.value*ctm.d;            
   };
 
   this.setFile = function (filename) {
      if (filename.toLowerCase().substr(-4,4) == '.jpg')
         showImage(filename)
      else if (filename.toLowerCase().substr(-5,5) == '.jpeg')
         showImage(filename)
      else if (filename.toLowerCase().substr(-4,4) == '.png')
         showImage(filename)
      else if (filename.toLowerCase().substr(-4,4) == '.bmp')
         showImage(filename)
      else if (filename.toLowerCase().substr(-4,4) == '.mp4')
         showVideo(filename)
      else 
         clear();
   };
 
   this.clear = function (filename) {
      if (image != null) {
         deleteOverlay(image);
         image = null;
      }
      if (video != null) {
         deleteOverlay(video);
         video = null;
      }
   }
   
   function showImage (filename) {
      if (video != null) {
         deleteOverlay(video)
         video = null;
      }
      if (image == null)
         image = createOverlay(root, imageArea, 'img');
      image.style.display = 'inline';      
      image.style.pointerEvents = 'none';
      image.src = filename;
   };

   function showVideo (filename) {
      if (image != null) {
         deleteOverlay(image);
         image = null;
      }
      if (video == null) 
         video = createOverlay(root, imageArea, 'video');
      else   
         video.removeChild(source)   
      source = document.createElement('source');
      source.type = 'video/mp4'
      source.src = filename;
      video.appendChild(source);      
      if (true || config.controls!=0) {
         video.setAttribute('controls', '');
         // video.load();
      }
      else {
         video.style.pointerEvents = 'none';
         video.removeAttribute('controls');   
         //video.play();
      }
   };

   function clear() {
      if (image != null) {
         deleteOverlay(image);
         image = null;
      }  
      if (video != null) {
         deleteOverlay(video);
         video = null;
      }   
   } 
   
   return this;
}
   


// C:/Program Files (x86)/Labcenter Electronics/Proteus 8 Professional/DATA/VSM Studio/controls/LineEdit/control.js

function LineEdit (root, config) {
   var obj = this;
   var border = root.getElementsByTagName('rect')[0];
   var bounds= root.getElementsByTagName('rect')[1];
   var clipRegion = root.getElementsByTagName('g')[0];
   var textArea = clipRegion.getElementsByTagName('rect')[0];
   var text = clipRegion.getElementsByTagName('text')[0];
   var placeHolder = clipRegion.getElementsByTagName('text')[1];
   var errorMessage = clipRegion.getElementsByTagName('text')[2];
   var input = root.input;
      
   setHotSpot(this, root);
   
   this.reconfigure = function (newInstance) {      
      if (newInstance) {
         config.textFont = getFontStyle(text);
         config.placeHolder = placeHolder.textContent;
      }
      placeHolder.textContent = config.placeHolder;
      this.setText("");
      this.setError("");
   };
   
   this.update = function () {
      // Force the border to have 1:1 aspect ratio at the panel level and retain it's stroke witdth:
      var ctm = root.getCTM();
      var bt = panel.createSVGTransform();
      bt.setScale(1/ctm.a, 1/ctm.d);
      border.transform.baseVal.initialize(bt);
      border.width.baseVal.value = bounds.width.baseVal.value*ctm.a;
      border.height.baseVal.value = bounds.height.baseVal.value*ctm.d;      
      
      // Force the text objects to have 1:1 aspect ratio at the panel level by compensating for any distortion.
      var tt = panel.createSVGTransform();
      tt.setScale(ctm.d/ctm.a, 1);
      text.transform.baseVal.initialize(tt);
      var pt = panel.createSVGTransform();
      pt.setScale(ctm.d/ctm.a, 1);
      placeHolder.transform.baseVal.initialize(pt);
      var et = panel.createSVGTransform();
      et.setScale(ctm.d/ctm.a, 1);
      errorMessage.transform.baseVal.initialize(et);
   };
   
   this.onmousedown = function (e) {
       if (input == null) {
            beginInput();
       } else {
            endInput();
       }
   }
   
   this.onmouseup = function (e) {
      return input != null; // capture continues whilst the input element is active
   }
    
   this.getText = function() {
      return input != null ? input.value : text.textContent;
   };

   this.setText = function(msg) {
      text.textContent = msg;
      if (input != null)
         input.value = msg;         
      placeHolder.style.display = (msg == "") ? '' : 'none'
   };

   this.clear = function() {
      text.textContent = text;
   };
   
   this.setError = function (msg) {
      errorMessage.textContent = msg;
   }      

   function beginInput () {
       if (input == null) {         
          var ctm = text.getCTM();
          input = createOverlay(root, textArea, 'input');            
          input.style.fontFamily = config.textFont.family;
          input.style.fontSize = config.textFont.size*ctm.d + 'px';
          input.value=text.textContent;
                
          input.type = 'text';
          input.readOnly = config.readOnly == 1;
          input.maxLength = config.maxLength;
          input.focus()

          textArea.style.fill = '#E0E0F0';
          text.style.display = 'none';
          placeHolder.style.display = 'none';
          errorMessage.textContent = "";          
                         
         // Set up event handles on the input element.
         input.onmousedown = function (e) { e.stopPropagation(); }
         input.onkeypress = function (e) {
            if (e.keyCode == 13) {
               text.textContent = input.value;
               postState(obj.id, "text", input.value);
               endInput();       
            } else if (e.keyCode == 27) {
               endInput();       
            }
         };
       }
   }
   
   function endInput () {
      if (input != null) {
         text.style.display = '';
         placeHolder.style.display = text.textContent == "" ? '' : 'none';
         textArea.style.fill = 'none';
         deleteOverlay(input);
         capture = null;
         input = null;
      }
   }
   
   return this;
};

